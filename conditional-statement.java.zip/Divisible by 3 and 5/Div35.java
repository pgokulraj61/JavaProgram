//Q14. Java Program to check whether a number is divisible by both 3 and 5


import java.util.*;
public class Div35
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt();
	    if(n%3==0 && n%5==0)
		System.out.println(n+ "it is divisible both");
		else
		System.out.println(n+ "it is not divisible");
	}
}
