//Q2.Java Program to find smallest among two numbers




import java.util.*;
public class Smallest
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int a = sc.nextInt();
	    int b = sc.nextInt();
	    if(a<b)
		System.out.println(a);
		else
		System.out.println(b);
	}
}
