import java.util.*;
public class DiffOddEven
{
	public static void main(String[] args) {
	    Scanner sc= new Scanner(System.in);
	    int a=sc.nextInt();
	    int b=sc.nextInt();
	    int diff=a-b;
	    if((diff & 1)==0)
		System.out.println("Even");
		else
		System.out.println("Odd");
	}
}
