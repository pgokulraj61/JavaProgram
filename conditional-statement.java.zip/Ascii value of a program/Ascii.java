//Q20.Java Program to check whether the ASCII value of a character is even or odd. logic





import java.util.*;
public class Ascii{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        char a=sc.next().charAt(0);
        int ascii=(int)a;
        if(ascii%2==0)
        System.out.println("Even");
        else
        System.out.println("odd");
    }
}