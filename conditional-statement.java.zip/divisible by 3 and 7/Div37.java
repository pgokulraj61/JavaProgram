import java.util.*;
public class Div37
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt();
	    if(n%3==0 || n%7==0)
		System.out.println(n+ "it divisible");
		else
		System.out.println(n+ "it is not divisible");
	}
}
