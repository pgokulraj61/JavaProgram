// Q13. Java Program to check whether a number is positive, negative, or zero



import java.util.*;
public class PositiveNegative
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int num=sc.nextInt();
	    if(num>0)
		System.out.println(num+"is positive");
		else if(num<0)
		System.out.println(num+"is negatuive");
		else
		System.out.println(num+"it is zero");
	}
}
