import java.util.*;
public class Divisible3
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt();
	    int lastDigit =Math.abs(n%10);
	    if(lastDigit %3 == 0)
		System.out.println(n+"is divisible");
		else
		System.out.println(n+"is not divisible");
	}
}
