//Q11. Java Program to check whether the first digit of a 3 digit number is odd or even



import java.util.*;
{
public class ThreeDigitOddEven
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt();
	    int firstDigit=(n % 100);
	    if(firstDigit %2 == 0)
		System.out.println("even");
		else
		System.out.println("odd");
	}
}
