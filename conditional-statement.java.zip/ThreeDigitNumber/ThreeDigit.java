//Q5.Java Program to find whether the given number is 3 digit number or not

import java.util.*;
public class ThreeDigit
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int a=sc.nextInt();
	    if((a>=100 && a<=999)||(a<=-100 && a>=-999))
		System.out.println(a+ "it is three digit");
		else
		System.out.println(a+ "it is not a three digit");
	}
}
