//Q14. Write a Java Program to print the cube of a given number



public class Cube {
    public static void main(String[] args) {
        int n =5;  
        int cube = n * n * n;

        System.out.println( + n +  + cube);
    }
}
