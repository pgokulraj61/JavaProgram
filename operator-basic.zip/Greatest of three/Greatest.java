//Q19.Write a Java Program to find the greatest of three numbers.



import java.util.*;
public class Greatest
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt();
	    int m=sc.nextInt();
	    int o=sc.nextInt();
	    int d=(n>m) ? n: m;
		System.out.println((d > o)? d :o);
	}
}
