//Q4.Write a Java Program to print Quoficient of two numbers

import java.util.*; 
public class Quoficient
{
	public static void main(String[] args) {
	    int a=10;
	    int b=20;
	    int c=a/b;
		System.out.println(c);
	}
}
