//Q12.Write a Java Program to print the absolute value of a given number.



import java.util.Scanner;
public class Absolute{
    public static void main (String[]args){
        Scanner sc=new Scanner(System.in);
        int num=sc.nextInt();
        int absolute=Math.abs(num);
        System.out.println(absolute);
    }
}