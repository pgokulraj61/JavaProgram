//Q5.Write a Java Program to print remainder of two numbers

import java.util.*; 
public class Remainder
{
	public static void main(String[] args) {
	    int a=10;
	    int b=20;
	    int c=a%b;
		System.out.println(c);
	}
}
