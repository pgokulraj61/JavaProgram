//Q8.Java Program to print the last digit of given number N

import java.util.*;

public class Digit {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int N = sc.nextInt();

        int digit = Math.abs(N % 10); 

        System.out.println("The last digit is: " + digit);
    }
}
