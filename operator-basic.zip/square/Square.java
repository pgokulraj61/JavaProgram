import java.util.Scanner;
public class Square
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    int a=sc.nextInt();
	    int c=a*a;
		System.out.println(c);
	}
}
