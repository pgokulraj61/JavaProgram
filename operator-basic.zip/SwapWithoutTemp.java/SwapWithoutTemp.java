//Q7.Write a Java Program to Swap of two numbers without using third variable


public class SwapWithoutTemp {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;

      
        
        a = a + b;  
        b = a - b;  
        a = a - b; 

        System.out.println("a = " + a);
        System.out.println("b = " + b);
    }
}
