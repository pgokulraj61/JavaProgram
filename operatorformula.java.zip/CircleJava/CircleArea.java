//Q4.Write a Java Program to find area of Javaircle


import java.util.Scanner;

public class CircleArea {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double radius = sc.nextDouble();
        double area = Math.PI * radius * radius;
        System.out.println(area);

        sc.close();
    }
}
