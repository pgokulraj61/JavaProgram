import java.util.Scanner;

public class CuboidProperties {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double length = sc.nextDouble();
        double breadth = sc.nextDouble();
        double height = sc.nextDouble();
        double surfaceArea = 2 * (length * breadth + breadth * height + length * height);
        double volume = length * breadth * height;
        System.out.println(surfaceArea);
        System.out.println(volume);

        sc.close();
    }
}
