//Q14.Write a Java Program to find Surface Area and Volume of a Sphere


import java.util.Scanner;

public class SphereProperties {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double radius = sc.nextDouble();
        double surfaceArea = 4 * Math.PI * radius * radius;
        double volume = (4.0 / 3) * Math.PI * radius * radius * radius;
        System.out.println(surfaceArea);
        System.out.println(volume);

        sc.close();
    }
}
