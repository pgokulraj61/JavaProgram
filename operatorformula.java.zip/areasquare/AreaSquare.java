//Q2.Write a Java Program to find area of Square




import java.util.Scanner;

public class AreaSquare {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double side = sc.nextDouble();
        double area = side * side;

        System.out.println(area);

        sc.close();
    }
}
