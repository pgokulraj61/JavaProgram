//Q8.Write a Java Program to find Perimeter of a Square



